
import { Injectable } from '@angular/core';
import { UIState, NgParam } from '@farris/devkit';

@Injectable()
export class StudentComponentViewmodelUIState extends UIState {
}
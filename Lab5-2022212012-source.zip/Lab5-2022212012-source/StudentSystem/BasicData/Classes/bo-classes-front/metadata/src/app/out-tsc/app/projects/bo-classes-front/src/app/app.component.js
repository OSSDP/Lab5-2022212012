import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'jit engine auto generated';
    }
    AppComponent = tslib_1.__decorate([
        Component({
            selector: 'app-root',
            template: '<router-outlet></router-outlet>',
            styleUrls: ['./app.component.scss']
        })
    ], AppComponent);
    return AppComponent;
}());
export { AppComponent };

import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { UIState } from '@farris/devkit';
var StudentComponentViewmodelUIState = /** @class */ (function (_super) {
    tslib_1.__extends(StudentComponentViewmodelUIState, _super);
    function StudentComponentViewmodelUIState() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    StudentComponentViewmodelUIState = tslib_1.__decorate([
        Injectable()
    ], StudentComponentViewmodelUIState);
    return StudentComponentViewmodelUIState;
}(UIState));
export { StudentComponentViewmodelUIState };

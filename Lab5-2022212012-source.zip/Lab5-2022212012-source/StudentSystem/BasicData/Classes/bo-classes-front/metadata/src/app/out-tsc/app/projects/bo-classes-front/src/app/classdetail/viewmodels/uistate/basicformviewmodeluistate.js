import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { UIState } from '@farris/devkit';
var BasicFormViewmodelUIState = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelUIState, _super);
    function BasicFormViewmodelUIState() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BasicFormViewmodelUIState = tslib_1.__decorate([
        Injectable()
    ], BasicFormViewmodelUIState);
    return BasicFormViewmodelUIState;
}(UIState));
export { BasicFormViewmodelUIState };
